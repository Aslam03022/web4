# jQuery Drag & Drop Matching Exercise

This is an exercise in which the user is presented with a collection of "answers" (e.g. "Apple", "Asparagus", "Android", etc)
and drags each answer into the appropriate category ("Fruits", "Vegetables", "Operating Systems"). Of course the answers and categories
can be customized to suit your application.

### Requires jQuery and jQuery UI.